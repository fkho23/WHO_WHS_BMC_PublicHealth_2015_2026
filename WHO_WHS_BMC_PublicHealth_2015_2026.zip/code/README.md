# Reproducibility package

Supplementary code and outputs for:

**Artificial Intelligence-Assisted Analysis of Global Public Health Priorities in WHO World Health Statistics Reports, 2015–2026: A Longitudinal Document and Indicator-Based Study**

This package accompanies the manuscript submitted to BMC Public Health. It contains the scripts and the real, programmatically generated outputs used in the manuscript's Methods and Results sections. No number in any file here was manually estimated; every file is the direct output of running the scripts in `scripts/` against the extracted report text.

## Scope note (read first)

Both the manual and computational scopes now cover the same twelve editions, matching the manuscript's Methods section exactly:

- **Manual extraction** (data-source inventory + 15-category thematic-indicator coding, in `supplementary_tables/`): WHS editions **2015–2026 (n=12)**. The 2017–2026 portion (n=10) was coded first; the 2015–2016 portion was added in a subsequent extension using the identical protocol, closing the earlier gap between the manual and computational scopes.
- **Computational text-mining pipeline** (everything in this `code/` folder): WHS editions **2015–2026 (n=12)**.
- The **2023** edition is included in the full descriptive corpus (preprocessing, term frequency, TF-IDF, topic modeling, clustering) and in the manual Stage 1–2 extraction, but is **excluded only** from the three-period Kruskal-Wallis comparison (2015–2019 / 2020–2022 / 2024–2026), by an a priori design decision, not a data-availability limitation.
- Neither **2019** nor **2023** is missing from any analysis in this package.

## Input data

The underlying WHO World Health Statistics PDF reports (2015–2026) are not redistributed here for copyright reasons. They are publicly available from WHO at https://www.who.int/data/gho/publications/world-health-statistics. Each edition was converted to page-tagged plain text using `pdftotext -layout` (Poppler), with page boundaries reconstructed from form-feed characters. That intermediate page-tagged text is the direct input to `scripts/pipeline_01_preprocess.py`.

## Environment

- Python 3.10.12
- Package versions pinned in `requirements.txt` (installed via `pip install -r requirements.txt`)
- All stochastic steps (train/test splitting, LDA initialization, k-means initialization) use a fixed random seed of 42 for exact reproducibility.

Two components deviate from the originally planned, idealized design because the analysis environment blocked outbound downloads of NLTK/spaCy language-model corpora and pretrained transformer models. This is disclosed in the manuscript's Methods and Limitations and is reflected in the code exactly as run:

- **Stemming (NLTK Snowball/Porter2)** was used in place of the originally planned spaCy lemmatization.
- **TF-IDF + Truncated SVD (latent semantic analysis)** was used in place of the originally planned transformer sentence-embedding approach for semantic clustering.

## How to reproduce

Run the scripts in `scripts/` in numeric order. Each script reads the output of the previous one from a local `pipeline/` working directory (paths are set at the top of each script and will need to be adjusted to your local environment):

1. `pipeline_01_preprocess.py` — cleaning, tokenization, stopword removal, stemming. Produces the page-level corpus and `preprocessing_log.csv`.
2. `pipeline_02_frequency_tfidf.py` — n-grams, term frequency, TF-IDF (report-level and period-level).
3. `pipeline_03_topics_clustering.py` — LDA topic modeling (page level, k selected by held-out perplexity) and TF-IDF+LSA+k-means semantic clustering (report level, k selected by silhouette score).
4. `pipeline_04_period_stats.py` — page-level Kruskal-Wallis tests (term rates and topic probabilities) across the three defined periods, with Benjamini-Hochberg FDR correction.
5. `pipeline_05_figures.py` — generates the four manuscript figures from the outputs of steps 1–3.

## File-by-file contents

| File | Contents |
|---|---|
| `processed_text_metadata.csv` | Page-level metadata for all 1,406 pages across 12 editions: year, PDF page index, raw token count, cleaned token count. |
| `preprocessing_log.csv` | Per-edition summary: page count, raw tokens, cleaned tokens, % reduction (Table 2 in the manuscript). |
| `term_frequency_by_report.csv` | Per-report-year unigram frequency counts and per-1,000-token rates (full vocabulary, not just top terms). |
| `tfidf_outputs.csv` | TF-IDF-distinctive terms, both report-year-level (top 20 per edition) and period-level (top 25 per period), distinguished by the `level` column. |
| `lda_topic_outputs.csv` | Multi-section file: k-selection diagnostics (held-out log-likelihood/perplexity), final k=6 topic word lists, topic prevalence by report-year, and topic prevalence by period. |
| `lda_page_topic_assignments_full.csv` | Full page-level raw output: dominant topic and per-topic probability for every one of the 1,281 modeled pages. Primary evidence file underlying the LDA results in `lda_topic_outputs.csv`. |
| `kruskal_wallis_fdr_results.csv` | All Kruskal-Wallis test results (60 terms + 6 LDA topics) with H-statistic, raw p-value, Benjamini-Hochberg FDR-adjusted q-value, and period means (Table 7 in the manuscript). |
| `figures/` | The four manuscript figures (PNG), generated directly from the CSVs above by `scripts/pipeline_05_figures.py`. |
| `supplementary_tables/` | The two manually coded Stage 1–2 Excel deliverables, both covering all twelve 2015–2026 editions: the 12-field data-source inventory (the 2015–2016 rows were added after the original 2017–2026 extraction, using the identical coding protocol) and the 15-category thematic-indicator extraction (181 coded rows, page-verified, with 19 verbatim quotations confirmed by exact-substring matching). |
| `scripts/` | The five pipeline scripts described above. |

## Known limitations of this package

- Whole-document-level term-frequency and TF-IDF outputs (not the page-level LDA outputs) are substantially influenced by each report's country-level statistical annex (country names, repeated table-header artifacts such as "comparable estimate"), as 