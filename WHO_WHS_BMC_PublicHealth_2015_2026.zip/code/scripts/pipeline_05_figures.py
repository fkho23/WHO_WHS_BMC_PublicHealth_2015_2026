"""
Real figures generated directly from the computed pipeline outputs
(preprocessing log, term frequency, LDA topic assignments, TF-IDF+LSA
clustering). No invented data.
"""
import json, pickle
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.cluster import KMeans

OUT_DIR = Path("/sessions/sharp-exciting-wozniak/mnt/outputs/pipeline")
FIG_DIR = OUT_DIR / "figures"
FIG_DIR.mkdir(exist_ok=True)

YEARS = list(range(2015, 2027))

# ---------------------------------------------------------------------
# Figure 1: corpus size overview (pages, raw tokens, clean tokens per year)
# ---------------------------------------------------------------------
log = pd.DataFrame(json.load(open(OUT_DIR / "preprocessing_log.json")))
fig, ax1 = plt.subplots(figsize=(9, 5))
ax1.bar(log.year, log.n_pages, color="#4C72B0", alpha=0.6, label="Pages per report")
ax1.set_xlabel("Report year")
ax1.set_ylabel("Number of pages", color="#4C72B0")
ax1.tick_params(axis="y", labelcolor="#4C72B0")
ax1.set_xticks(YEARS)

ax2 = ax1.twinx()
ax2.plot(log.year, log.tokens_raw, marker="o", color="#DD8452", label="Raw tokens")
ax2.plot(log.year, log.tokens_after_cleaning, marker="s", color="#55A868", label="Clean tokens (post stopword removal + stemming)")
ax2.set_ylabel("Token count")

lines, labels = [], []
for ax in (ax1, ax2):
    l, lab = ax.get_legend_handles_labels()
    lines += l; labels += lab
ax1.legend(lines, labels, loc="upper right", fontsize=8)
plt.title("Figure 1. Corpus size by report edition, 2015-2026")
plt.tight_layout()
plt.savefig(FIG_DIR / "figure1_corpus_size.png", dpi=200)
plt.close()

# ---------------------------------------------------------------------
# Figure 2: term-frequency trends for selected substantive terms, 2015-2026
# ---------------------------------------------------------------------
tf = pd.read_csv(OUT_DIR / "term_frequency_by_report.csv")
selected_terms = ["covid-", "region", "global", "progress", "sdgs", "mortal", "coverag", "diseas"]
selected_terms = [t for t in selected_terms if t in tf.term.unique()]
fig, ax = plt.subplots(figsize=(9, 5))
for term in selected_terms:
    sub = tf[tf.term == term].sort_values("year")
    ax.plot(sub.year, sub.freq_per_1000, marker="o", label=term)
ax.set_xlabel("Report year")
ax.set_ylabel("Frequency per 1,000 tokens")
ax.set_xticks(YEARS)
ax.axvspan(2019.5, 2022.5, color="grey", alpha=0.08)
ax.legend(fontsize=8, ncol=2)
plt.title("Figure 2. Frequency trends of selected terms across WHS editions, 2015-2026\n(shaded band = 2020-2022 pandemic-disruption period)")
plt.tight_layout()
plt.savefig(FIG_DIR / "figure2_term_trends.png", dpi=200)
plt.close()

# ---------------------------------------------------------------------
# Figure 3: LDA topic prevalence by report-year (stacked bar)
# ---------------------------------------------------------------------
prev = pd.read_csv(OUT_DIR / "lda_topic_prevalence_by_year.csv")
topic_words = pd.read_csv(OUT_DIR / "lda_topic_words.csv")
topic_labels = {row.topic: ", ".join(row.top_words_label.split(", ")[:3]) for row in topic_words.itertuples()}

pivot = prev.pivot(index="year", columns="dominant_topic", values="share").fillna(0)
pivot = pivot.reindex(YEARS).fillna(0)
fig, ax = plt.subplots(figsize=(10, 5.5))
bottom = np.zeros(len(pivot))
colors = plt.cm.tab10.colors
for i, topic in enumerate(pivot.columns):
    ax.bar(pivot.index, pivot[topic], bottom=bottom, label=f"Topic {topic}: {topic_labels.get(topic, '')}",
           color=colors[i % 10])
    bottom += pivot[topic].values
ax.set_xlabel("Report year")
ax.set_ylabel("Share of pages (dominant topic)")
ax.set_xticks(YEARS)
ax.legend(fontsize=7, loc="upper center", bbox_to_anchor=(0.5, -0.15), ncol=2)
plt.title(f"Figure 3. LDA topic prevalence by report edition, 2015-2026 (k={len(pivot.columns)} topics)")
plt.tight_layout()
plt.savefig(FIG_DIR / "figure3_topic_prevalence.png", dpi=200)
plt.close()

# ---------------------------------------------------------------------
# Figure 4: semantic clustering -- LSA 2D projection of report-years
# (recomputes the same deterministic TF-IDF+SVD+KMeans pipeline as
# pipeline_03, random_state=42, to obtain 2D coordinates for plotting)
# ---------------------------------------------------------------------
corpus = pickle.load(open(OUT_DIR / "corpus.pkl", "rb"))
report_docs = {y: " ".join(t for p in corpus[y]["pages"] for t in p["tokens"]) for y in YEARS}
tfidf_vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True,
                                    token_pattern=r"(?u)\b\w[\w\-]+\b")
X_tfidf = tfidf_vectorizer.fit_transform([report_docs[y] for y in YEARS])
n_comp = min(10, X_tfidf.shape[1] - 1, X_tfidf.shape[0] - 1)
svd = TruncatedSVD(n_components=n_comp, random_state=42)
X_lsa = svd.fit_transform(X_tfidf)

clusters_df = pd.read_csv(OUT_DIR / "kmeans_report_clusters.csv")
km_k = clusters_df.cluster.nunique()
km = KMeans(n_clusters=km_k, random_state=42, n_init=10)
labels = km.fit_predict(X_lsa)

fig, ax = plt.subplots(figsize=(7.5, 6.5))
scatter = ax.scatter(X_lsa[:, 0], X_lsa[:, 1], c=labels, cmap="tab10", s=110, edgecolor="k")
for i, y in enumerate(YEARS):
    ax.annotate(str(y), (X_lsa[i, 0], X_lsa[i, 1]), textcoords="offset points", xytext=(6, 4), fontsize=9)
ax.set_xlabel(f"LSA component 1 ({svd.explained_variance_ratio_[0]*100:.1f}% var.)")
ax.set_ylabel(f"LSA component 2 ({svd.explained_variance_ratio_[1]*100:.1f}% var.)")
plt.title(f"Figure 4. Semantic clustering of report-years\n(TF-IDF + LSA + KMeans, k={km_k}, silhouette={json.load(open(OUT_DIR/'topics_clustering_summary.json'))['kmeans_silhouette']:.3f})")
plt.tight_layout()
plt.savefig(FIG_DIR / "figure4_semantic_clustering.png", dpi=200)
plt.close()

print("Saved figures to", FIG_DIR)
for f in sorted(FIG_DIR.glob("*.png")):
    print(" -", f.name)
