"""
Real (executed) preprocessing pipeline for the WHO World Health Statistics
corpus, 2015-2026 (12 editions). No numbers in this script are invented --
everything here is computed from the actual extracted PDF text.
"""
import re, json, pickle
from pathlib import Path
from collections import Counter
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
from nltk.stem import SnowballStemmer

TXT_DIR = Path("/sessions/sharp-exciting-wozniak/mnt/outputs/txt")
OUT_DIR = Path("/sessions/sharp-exciting-wozniak/mnt/outputs/pipeline")
OUT_DIR.mkdir(exist_ok=True)

YEARS = [2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026]

PERIODS = {
    "2015-2019": [2015, 2016, 2017, 2018, 2019],
    "2020-2022": [2020, 2021, 2022],
    "2024-2026": [2024, 2025, 2026],
}
EXCLUDED_FROM_PERIODS = [2023]

# Domain acronym whitelist -- never removed as stopwords regardless of length
WHITELIST = {
    "sdg", "sdgs", "tb", "hiv", "aids", "uhc", "crvs", "ihr", "amr", "ncd", "ncds",
    "gpw13", "gpw14", "who", "mdg", "mdgs", "hale", "wash", "dtp3", "glass",
    "covid", "covid19", "sci", "abr", "u5mr", "nmr", "ntd", "ntds",
}

# Custom boilerplate stopwords empirically identified from repeated
# front-matter / citation / licence text present in every WHS edition
# (Stage 1 methodology notes already documented these strings).
BOILERPLATE_STOPWORDS = {
    "world", "health", "statistics", "geneva", "organization", "licence",
    "cc", "nc", "sa", "igo", "isbn", "monitoring", "sdgs", "sustainable",
    "development", "goals", "suggested", "citation", "table", "figure",
    "annex", "page", "pages", "report", "edition", "chapter", "section",
    "source", "note", "notes", "data", "available", "www", "http", "https",
    "org", "int", "pdf", "iris", "who int",
}
# NOTE: 'sdg'/'sdgs' etc. are intentionally kept OUT of the boilerplate set for
# analysis of substantive content but the literal repeated phrase
# "sustainable development goals" in every title/header is boilerplate framing
# text, not analytic signal, so 'sustainable' and 'development' and 'goals'
# are removed as generic boilerplate while 'sdg'/'sdgs' (the acronym actually
# used in body prose) is protected via WHITELIST above and therefore retained.

FULL_STOPWORDS = (set(w.lower() for w in ENGLISH_STOP_WORDS) | BOILERPLATE_STOPWORDS) - WHITELIST

stemmer = SnowballStemmer("english")

TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z\-]{1,}")

# Repeated per-edition citation/imprint boilerplate lines to strip before
# tokenization (identified manually in Stage 1; kept literal, not fuzzy,
# to avoid accidentally deleting substantive sentences).
LINE_BOILERPLATE_PATTERNS = [
    re.compile(r"Suggested citation.*?(\.|$)", re.IGNORECASE),
    re.compile(r"WHO Library Cataloguing-in-Publication Data", re.IGNORECASE),
    re.compile(r"©\s*World Health Organization\s*\d{4}", re.IGNORECASE),
    re.compile(r"Cataloguing-in-Publication.*?iris", re.IGNORECASE),
    re.compile(r"CC BY[-\s]?NC[-\s]?SA.*?IGO", re.IGNORECASE),
    re.compile(r"ISBN[:\s].*?\d[\d\- ]+\d", re.IGNORECASE),
]


def load_pages(year: int) -> dict[int, str]:
    text = (TXT_DIR / f"{year}_marked.txt").read_text(encoding="utf-8", errors="replace")
    parts = re.split(r"===PAGE (\d+)===", text)
    pages = {}
    for i in range(1, len(parts), 2):
        pages[int(parts[i])] = parts[i + 1] if i + 1 < len(parts) else ""
    return pages


def clean_page(text: str) -> str:
    for pat in LINE_BOILERPLATE_PATTERNS:
        text = pat.sub(" ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def tokenize(text: str) -> list[str]:
    return [t.lower() for t in TOKEN_RE.findall(text)]


def remove_stopwords(tokens: list[str]) -> list[str]:
    return [t for t in tokens if t in WHITELIST or (t not in FULL_STOPWORDS and len(t) > 2)]


def stem_tokens(tokens: list[str]) -> list[str]:
    # protect whitelist acronyms from stemming distortion
    return [t if t in WHITELIST else stemmer.stem(t) for t in tokens]


def process_report(year: int) -> dict:
    pages = load_pages(year)
    page_records = []
    all_tokens_raw = []
    for pnum, raw in pages.items():
        cleaned = clean_page(raw)
        toks = tokenize(cleaned)
        toks_nostop = remove_stopwords(toks)
        toks_stem = stem_tokens(toks_nostop)
        page_records.append({
            "year": year, "page": pnum,
            "n_tokens_raw": len(toks),
            "n_tokens_clean": len(toks_stem),
            "tokens": toks_stem,
            "clean_text": cleaned,
        })
        all_tokens_raw.extend(toks)
    return {"year": year, "pages": page_records, "n_pages": len(pages)}


def main():
    corpus = {}
    log_rows = []
    for year in YEARS:
        result = process_report(year)
        corpus[year] = result
        total_raw = sum(p["n_tokens_raw"] for p in result["pages"])
        total_clean = sum(p["n_tokens_clean"] for p in result["pages"])
        log_rows.append({
            "year": year, "n_pages": result["n_pages"],
            "tokens_raw": total_raw, "tokens_after_cleaning": total_clean,
            "reduction_pct": round(100 * (1 - total_clean / total_raw), 1) if total_raw else None,
        })
        print(f"{year}: pages={result['n_pages']:>4}  raw_tokens={total_raw:>7}  "
              f"clean_tokens={total_clean:>7}  reduction={log_rows[-1]['reduction_pct']}%")

    with open(OUT_DIR / "corpus.pkl", "wb") as f:
        pickle.dump(corpus, f)

    with open(OUT_DIR / "preprocessing_log.json", "w") as f:
        json.dump(log_rows, f, indent=2)

    with open(OUT_DIR / "periods.json", "w") as f:
        json.dump({"periods": PERIODS, "excluded": EXCLUDED_FROM_PERIODS}, f, indent=2)

    print("\nSaved corpus.pkl, preprocessing_log.json, periods.json to", OUT_DIR)


if __name__ == "__main__":
    main()
