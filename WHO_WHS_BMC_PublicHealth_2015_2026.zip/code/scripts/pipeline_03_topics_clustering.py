"""
Real (executed) topic modeling and semantic clustering on the WHO WHS
corpus, 2015-2026. Page-level LDA topic modeling (Task 28) and report-level
TF-IDF+SVD+KMeans semantic clustering (Task 29). Nothing here is invented --
all numbers are direct output of scikit-learn fit on the real corpus.
"""
import json, pickle, re
from pathlib import Path
from collections import Counter, defaultdict
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer, ENGLISH_STOP_WORDS
from sklearn.decomposition import LatentDirichletAllocation, TruncatedSVD
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.model_selection import train_test_split

OUT_DIR = Path("/sessions/sharp-exciting-wozniak/mnt/outputs/pipeline")
TXT_DIR = Path("/sessions/sharp-exciting-wozniak/mnt/outputs/txt")
corpus = pickle.load(open(OUT_DIR / "corpus.pkl", "rb"))
periods_cfg = json.load(open(OUT_DIR / "periods.json"))
PERIODS = periods_cfg["periods"]
EXCLUDED = periods_cfg["excluded"]
YEARS = sorted(corpus.keys())

def period_of(year):
    for pname, yrs in PERIODS.items():
        if year in yrs:
            return pname
    return "excluded" if year in EXCLUDED else None

# ---------------------------------------------------------------------
# 0. Build stem -> representative surface-form map (for readable labels).
#    We re-tokenize the already-cleaned page text (clean_text, pre-stem)
#    and count which raw lowercase word most often produced each stem.
#    This is purely a labeling aid for the manuscript; all quantitative
#    results below operate on the real stemmed tokens.
# ---------------------------------------------------------------------
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS as _ESW
from nltk.stem import SnowballStemmer
stemmer = SnowballStemmer("english")
TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z\-]{1,}")
WHITELIST = {
    "sdg", "sdgs", "tb", "hiv", "aids", "uhc", "crvs", "ihr", "amr", "ncd", "ncds",
    "gpw13", "gpw14", "who", "mdg", "mdgs", "hale", "wash", "dtp3", "glass",
    "covid", "covid19", "sci", "abr", "u5mr", "nmr", "ntd", "ntds",
}
BOILERPLATE_STOPWORDS = {
    "world", "health", "statistics", "geneva", "organization", "licence",
    "cc", "nc", "sa", "igo", "isbn", "monitoring", "sdgs", "sustainable",
    "development", "goals", "suggested", "citation", "table", "figure",
    "annex", "page", "pages", "report", "edition", "chapter", "section",
    "source", "note", "notes", "data", "available", "www", "http", "https",
    "org", "int", "pdf", "iris", "who int",
}
FULL_STOPWORDS = (set(w.lower() for w in _ESW) | BOILERPLATE_STOPWORDS) - WHITELIST

stem_surface_counts = defaultdict(Counter)
for year, rec in corpus.items():
    for page in rec["pages"]:
        toks = [t.lower() for t in TOKEN_RE.findall(page["clean_text"])]
        toks = [t for t in toks if t in WHITELIST or (t not in FULL_STOPWORDS and len(t) > 2)]
        for t in toks:
            s = t if t in WHITELIST else stemmer.stem(t)
            stem_surface_counts[s][t] += 1

stem_label = {s: c.most_common(1)[0][0] for s, c in stem_surface_counts.items()}

def label(stem_or_phrase: str) -> str:
    parts = stem_or_phrase.split()
    return " ".join(stem_label.get(p, p) for p in parts)

# ---------------------------------------------------------------------
# 1. Page-level documents for topic modeling
# ---------------------------------------------------------------------
page_rows = []
for year, rec in corpus.items():
    for page in rec["pages"]:
        page_rows.append({
            "year": year, "page": page["page"],
            "n_tokens": page["n_tokens_clean"],
            "text": " ".join(page["tokens"]),
            "period": period_of(year),
        })
page_df = pd.DataFrame(page_rows)
# drop very sparse pages (mostly numeric/table fragments with almost no
# retained vocabulary) -- keep pages with at least 15 clean tokens
page_df_model = page_df[page_df.n_tokens >= 15].reset_index(drop=True)
print(f"Total pages: {len(page_df)}; pages retained for topic modeling (>=15 clean tokens): {len(page_df_model)}")

cv = CountVectorizer(max_df=0.90, min_df=8, token_pattern=r"(?u)\b\w[\w\-]+\b")
dtm = cv.fit_transform(page_df_model["text"])
vocab = cv.get_feature_names_out()
print(f"LDA vocabulary size: {len(vocab)}; document-term matrix shape: {dtm.shape}")

# ---------------------------------------------------------------------
# 2. Choose k via held-out log-likelihood (perplexity proxy) on a
#    train/test split of pages
# ---------------------------------------------------------------------
train_idx, test_idx = train_test_split(np.arange(dtm.shape[0]), test_size=0.2, random_state=42)
dtm_train, dtm_test = dtm[train_idx], dtm[test_idx]

k_candidates = [6, 8, 10, 12, 15]
k_scores = []
for k in k_candidates:
    lda_k = LatentDirichletAllocation(n_components=k, random_state=42, learning_method="batch",
                                       max_iter=25, n_jobs=-1)
    lda_k.fit(dtm_train)
    ll = lda_k.score(dtm_test)          # held-out log-likelihood (higher = better fit)
    perp = lda_k.perplexity(dtm_test)   # held-out perplexity (lower = better fit)
    k_scores.append({"k": k, "held_out_loglik": float(ll), "held_out_perplexity": float(perp)})
    print(f"k={k:>2}  held-out log-likelihood={ll:,.1f}  held-out perplexity={perp:,.1f}")

k_scores_df = pd.DataFrame(k_scores)
k_scores_df.to_csv(OUT_DIR / "lda_k_selection.csv", index=False)
best_k = int(k_scores_df.loc[k_scores_df.held_out_perplexity.idxmin(), "k"])
print(f"\nSelected k (lowest held-out perplexity) = {best_k}")

# ---------------------------------------------------------------------
# 3. Fit final LDA at chosen k on the full page-level DTM
# ---------------------------------------------------------------------
lda = LatentDirichletAllocation(n_components=best_k, random_state=42, learning_method="batch",
                                 max_iter=50, n_jobs=-1)
doc_topic = lda.fit_transform(dtm)

topic_words = []
for t_idx, comp in enumerate(lda.components_):
    top_idx = comp.argsort()[::-1][:15]
    words_stem = [vocab[i] for i in top_idx]
    words_label = [label(w) for w in words_stem]
    topic_words.append({"topic": t_idx, "top_words_stem": ", ".join(words_stem),
                         "top_words_label": ", ".join(words_label)})
    print(f"Topic {t_idx}: {', '.join(words_label)}")
topic_words_df = pd.DataFrame(topic_words)
topic_words_df.to_csv(OUT_DIR / "lda_topic_words.csv", index=False)

# dominant topic per page + full topic-probability matrix
page_df_model = page_df_model.copy()
page_df_model["dominant_topic"] = doc_topic.argmax(axis=1)
for t_idx in range(best_k):
    page_df_model[f"topic_{t_idx}_prob"] = doc_topic[:, t_idx]
page_df_model.to_csv(OUT_DIR / "lda_page_topic_assignments.csv", index=False)

# topic prevalence (share of pages whose dominant topic = t) by report-year and by period
counts_year = page_df_model.groupby(["year", "dominant_topic"]).size().rename("n").reset_index()
counts_year["share"] = counts_year.groupby("year")["n"].transform(lambda s: s / s.sum())
prevalence_year = counts_year
prevalence_year.to_csv(OUT_DIR / "lda_topic_prevalence_by_year.csv", index=False)

counts_period = (page_df_model[page_df_model.period != "excluded"]
                  .groupby(["period", "dominant_topic"]).size().rename("n").reset_index())
counts_period["share"] = counts_period.groupby("period")["n"].transform(lambda s: s / s.sum())
prevalence_period = counts_period
prevalence_period.to_csv(OUT_DIR / "lda_topic_prevalence_by_period.csv", index=False)
print("\nTopic prevalence by period (share of dominant-topic pages):")
print(prevalence_period.pivot(index="dominant_topic", columns="period", values="share").fillna(0).round(3))

# ---------------------------------------------------------------------
# 4. Semantic clustering: report-level TF-IDF + TruncatedSVD (LSA) + KMeans
#    (transformer sentence-embeddings were planned in Stage 3 but model
#    downloads are blocked in this sandbox; TF-IDF+LSA is a documented,
#    transparent substitute operating on the same real corpus.)
# ---------------------------------------------------------------------
report_docs = {y: " ".join(t for p in corpus[y]["pages"] for t in p["tokens"]) for y in YEARS}
tfidf_vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True,
                                    token_pattern=r"(?u)\b\w[\w\-]+\b")
X_tfidf = tfidf_vectorizer.fit_transform([report_docs[y] for y in YEARS])

n_comp = min(10, X_tfidf.shape[1] - 1, X_tfidf.shape[0] - 1)
svd = TruncatedSVD(n_components=n_comp, random_state=42)
X_lsa = svd.fit_transform(X_tfidf)
print(f"\nLSA explained variance ratio (first {n_comp} components): "
      f"{svd.explained_variance_ratio_.round(3).tolist()}  "
      f"(cumulative={svd.explained_variance_ratio_.sum():.3f})")

cluster_results = []
best_sil, best_kc, best_labels = -1, None, None
for kc in range(2, 6):
    km = KMeans(n_clusters=kc, random_state=42, n_init=10)
    labels_kc = km.fit_predict(X_lsa)
    sil = silhouette_score(X_lsa, labels_kc)
    cluster_results.append({"k": kc, "silhouette": float(sil)})
    print(f"KMeans k={kc}  silhouette={sil:.3f}  assignment={dict(zip(YEARS, labels_kc.tolist()))}")
    if sil > best_sil:
        best_sil, best_kc, best_labels = sil, kc, labels_kc

pd.DataFrame(cluster_results).to_csv(OUT_DIR / "kmeans_k_selection.csv", index=False)
print(f"\nSelected k (highest silhouette) = {best_kc}, silhouette = {best_sil:.3f}")

cluster_df = pd.DataFrame({"year": YEARS, "period": [period_of(y) for y in YEARS], "cluster": best_labels})
cluster_df.to_csv(OUT_DIR / "kmeans_report_clusters.csv", index=False)
print(cluster_df.to_string(index=False))

# top distinguishing TF-IDF terms per cluster centroid (via original TF-IDF space,
# approximated by averaging TF-IDF vectors of member report-years)
tfidf_terms = tfidf_vectorizer.get_feature_names_out()
X_tfidf_arr = X_tfidf.toarray()
cluster_top_terms = []
for c in sorted(set(best_labels)):
    idxs = [i for i, lab in enumerate(best_labels) if lab == c]
    centroid = X_tfidf_arr[idxs].mean(axis=0)
    top_idx = centroid.argsort()[::-1][:15]
    terms = [(label(tfidf_terms[j]), round(float(centroid[j]), 4)) for j in top_idx]
    cluster_top_terms.append({"cluster": int(c), "years": [int(YEARS[i]) for i in idxs],
                               "top_terms": terms})
    print(f"\nCluster {c} (years={[YEARS[i] for i in idxs]}): "
          + ", ".join(f"{t}({v})" for t, v in terms[:10]))
json.dump(cluster_top_terms, open(OUT_DIR / "kmeans_cluster_top_terms.json", "w"), indent=2)

# ---------------------------------------------------------------------
# 5. Save label map + summary
# ---------------------------------------------------------------------
json.dump({s: l for s, l in stem_label.items()}, open(OUT_DIR / "stem_surface_label_map.json", "w"), indent=2)

summary = {
    "n_pages_total": int(len(page_df)),
    "n_pages_modeled": int(len(page_df_model)),
    "lda_vocab_size": int(len(vocab)),
    "lda_k_selected": best_k,
    "kmeans_k_selected": int(best_kc),
    "kmeans_silhouette": float(best_sil),
    "lsa_n_components": int(n_comp),
    "lsa_cumulative_explained_variance": float(svd.explained_variance_ratio_.sum()),
}
json.dump(summary, open(OUT_DIR / "topics_clustering_summary.json", "w"), indent=2)
print("\nSummary:", summary)
