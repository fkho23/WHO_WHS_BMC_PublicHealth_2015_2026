"""
Real n-gram, term-frequency, and TF-IDF analysis on the preprocessed
WHO WHS corpus (2015-2026). All numbers computed here are actual outputs
of scikit-learn fit on the real corpus -- nothing is invented.
"""
import json, pickle
from pathlib import Path
from collections import Counter
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer

OUT_DIR = Path("/sessions/sharp-exciting-wozniak/mnt/outputs/pipeline")
corpus = pickle.load(open(OUT_DIR / "corpus.pkl", "rb"))
periods_cfg = json.load(open(OUT_DIR / "periods.json"))
PERIODS = periods_cfg["periods"]
EXCLUDED = periods_cfg["excluded"]

YEARS = sorted(corpus.keys())

# report-level "document" = all stemmed tokens from all pages, space-joined
report_docs = {}
report_token_lists = {}
for year, rec in corpus.items():
    toks = [t for page in rec["pages"] for t in page["tokens"]]
    report_token_lists[year] = toks
    report_docs[year] = " ".join(toks)

# ---------- N-gram extraction (CountVectorizer, unigrams-trigrams) ----------
ngram_vectorizer = CountVectorizer(ngram_range=(1, 3), min_df=2, token_pattern=r"(?u)\b\w[\w\-]+\b")
ngram_matrix = ngram_vectorizer.fit_transform([report_docs[y] for y in YEARS])
ngram_terms = ngram_vectorizer.get_feature_names_out()

ngram_rows = []
for i, year in enumerate(YEARS):
    row = ngram_matrix[i].toarray().flatten()
    for term_idx in row.nonzero()[0]:
        ngram_rows.append({"year": year, "ngram": ngram_terms[term_idx], "count": int(row[term_idx])})
ngram_df = pd.DataFrame(ngram_rows)
ngram_df.to_csv(OUT_DIR / "ngrams_by_report.csv", index=False)

# top multi-word (bigram/trigram) phrases corpus-wide, by total count
multiword = ngram_df[ngram_df["ngram"].str.contains(" ")]
top_multiword = (multiword.groupby("ngram")["count"].sum()
                  .sort_values(ascending=False).head(40).reset_index())
top_multiword.to_csv(OUT_DIR / "top_multiword_phrases.csv", index=False)
print("Top 15 multi-word phrases (corpus-wide, real counts):")
print(top_multiword.head(15).to_string(index=False))

# ---------- Term frequency (unigrams), per report and per period ----------
tf_rows = []
for year in YEARS:
    toks = report_token_lists[year]
    total = len(toks)
    counts = Counter(toks)
    for term, freq in counts.items():
        if " " in term:
            continue
        tf_rows.append({"year": year, "term": term, "freq": freq,
                         "freq_per_1000": round(freq / total * 1000, 3)})
tf_df = pd.DataFrame(tf_rows)
tf_df.to_csv(OUT_DIR / "term_frequency_by_report.csv", index=False)

def period_of(year):
    for pname, yrs in PERIODS.items():
        if year in yrs:
            return pname
    return "excluded" if year in EXCLUDED else None

tf_df["period"] = tf_df["year"].apply(period_of)
period_tf = (tf_df[tf_df.period != "excluded"]
             .groupby(["period", "term"])["freq_per_1000"].mean().reset_index())
period_tf.to_csv(OUT_DIR / "term_frequency_by_period.csv", index=False)

print("\nTop 15 terms by mean freq/1000 tokens, per period:")
for pname in PERIODS:
    top = period_tf[period_tf.period == pname].sort_values("freq_per_1000", ascending=False).head(15)
    print(f"\n-- {pname} --")
    print(top.to_string(index=False))

# ---------- TF-IDF: document = report-year ----------
tfidf_vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True,
                                    token_pattern=r"(?u)\b\w[\w\-]+\b")
tfidf_matrix = tfidf_vectorizer.fit_transform([report_docs[y] for y in YEARS])
tfidf_terms = tfidf_vectorizer.get_feature_names_out()

tfidf_rows = []
top_per_report = {}
for i, year in enumerate(YEARS):
    row = tfidf_matrix[i].toarray().flatten()
    top_idx = row.argsort()[::-1][:20]
    top_per_report[year] = [(tfidf_terms[j], round(float(row[j]), 4)) for j in top_idx if row[j] > 0]
    for j in top_idx:
        if row[j] > 0:
            tfidf_rows.append({"year": year, "term": tfidf_terms[j], "tfidf": round(float(row[j]), 4)})
pd.DataFrame(tfidf_rows).to_csv(OUT_DIR / "tfidf_top20_by_report.csv", index=False)

print("\nTop 10 TF-IDF-distinctive terms per report-year (real, computed):")
for year in YEARS:
    terms = ", ".join(f"{t}({v})" for t, v in top_per_report[year][:10])
    print(f"{year}: {terms}")

# ---------- TF-IDF: document = period ----------
period_docs = {}
for pname, yrs in PERIODS.items():
    period_docs[pname] = " ".join(report_docs[y] for y in yrs)
pnames = list(period_docs.keys())
tfidf_p_vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=1, sublinear_tf=True,
                                      token_pattern=r"(?u)\b\w[\w\-]+\b")
tfidf_p_matrix = tfidf_p_vectorizer.fit_transform([period_docs[p] for p in pnames])
tfidf_p_terms = tfidf_p_vectorizer.get_feature_names_out()

period_top_rows = []
for i, pname in enumerate(pnames):
    row = tfidf_p_matrix[i].toarray().flatten()
    top_idx = row.argsort()[::-1][:25]
    for j in top_idx:
        if row[j] > 0:
            period_top_rows.append({"period": pname, "term": tfidf_p_terms[j], "tfidf": round(float(row[j]), 4)})
period_tfidf_df = pd.DataFrame(period_top_rows)
period_tfidf_df.to_csv(OUT_DIR / "tfidf_top25_by_period.csv", index=False)

print("\nTop 15 TF-IDF-distinctive terms per PERIOD (real, computed; 2023 excluded from period docs):")
for pname in pnames:
    sub = period_tfidf_df[period_tfidf_df.period == pname].head(15)
    print(f"\n-- {pname} --")
    print(sub.to_string(index=False))

# save vocab sizes etc. for methods reporting
summary = {
    "n_reports": len(YEARS),
    "years": YEARS,
    "ngram_vocab_size": int(len(ngram_terms)),
    "tfidf_report_vocab_size": int(len(tfidf_terms)),
    "tfidf_period_vocab_size": int(len(tfidf_p_terms)),
    "total_clean_tokens_all_reports": int(sum(len(v) for v in report_token_lists.values())),
}
json.dump(summary, open(OUT_DIR / "freq_tfidf_summary.json", "w"), indent=2)
print("\nSummary:", summary)
