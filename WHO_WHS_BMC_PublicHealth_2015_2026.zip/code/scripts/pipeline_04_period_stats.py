"""
Real (executed) period-based statistical comparison: page-level term
frequencies and LDA topic probabilities compared across the three defined
periods (2015-2019, 2020-2022, 2024-2026; 2023 excluded from period
comparison per the study's period design). Kruskal-Wallis H-test per term
/ topic, Benjamini-Hochberg FDR correction across all tests. Nothing here
is invented -- all statistics are computed on the real corpus.
"""
import json, pickle
from pathlib import Path
from collections import Counter
import numpy as np
import pandas as pd
from scipy import stats

OUT_DIR = Path("/sessions/sharp-exciting-wozniak/mnt/outputs/pipeline")
corpus = pickle.load(open(OUT_DIR / "corpus.pkl", "rb"))
periods_cfg = json.load(open(OUT_DIR / "periods.json"))
PERIODS = periods_cfg["periods"]
EXCLUDED = periods_cfg["excluded"]

def period_of(year):
    for pname, yrs in PERIODS.items():
        if year in yrs:
            return pname
    return "excluded" if year in EXCLUDED else None

def bh_fdr(pvals):
    """Benjamini-Hochberg FDR correction, no external deps."""
    pvals = np.asarray(pvals, dtype=float)
    n = len(pvals)
    order = np.argsort(pvals)
    ranked = pvals[order]
    fdr = ranked * n / (np.arange(n) + 1)
    fdr = np.minimum.accumulate(fdr[::-1])[::-1]
    fdr = np.clip(fdr, 0, 1)
    out = np.empty(n)
    out[order] = fdr
    return out

# ---------------------------------------------------------------------
# 1. Page-level term-rate table (per-1000-token rate of each term, per page)
# ---------------------------------------------------------------------
page_records = []
for year, rec in corpus.items():
    p = period_of(year)
    for page in rec["pages"]:
        page_records.append({"year": year, "page": page["page"], "period": p,
                              "n_tokens": page["n_tokens_clean"], "tokens": page["tokens"]})

# corpus-wide term frequency to pick a candidate term set (top 60 most frequent
# unigrams overall, restricted to pages with >=15 clean tokens, consistent
# with the topic-modeling page filter)
page_records_f = [r for r in page_records if r["n_tokens"] >= 15]
overall_counts = Counter()
for r in page_records_f:
    overall_counts.update(r["tokens"])
top_terms = [t for t, _ in overall_counts.most_common(60)]

rows = []
for r in page_records_f:
    if r["period"] == "excluded":
        continue
    n = r["n_tokens"]
    c = Counter(r["tokens"])
    for term in top_terms:
        rate = c.get(term, 0) / n * 1000
        rows.append({"year": r["year"], "period": r["period"], "term": term, "rate_per_1000": rate})
term_page_df = pd.DataFrame(rows)
term_page_df.to_csv(OUT_DIR / "term_page_level_rates.csv", index=False)

kw_rows = []
for term in top_terms:
    sub = term_page_df[term_page_df.term == term]
    groups = [sub[sub.period == p]["rate_per_1000"].values for p in PERIODS.keys()]
    if any(len(g) < 2 for g in groups):
        continue
    h, p_val = stats.kruskal(*groups)
    means = {p: float(sub[sub.period == p]["rate_per_1000"].mean()) for p in PERIODS.keys()}
    kw_rows.append({"term": term, "H": float(h), "p_value": float(p_val),
                     "mean_2015_2019": means["2015-2019"], "mean_2020_2022": means["2020-2022"],
                     "mean_2024_2026": means["2024-2026"],
                     "n_pages_2015_2019": int(len(groups[0])), "n_pages_2020_2022": int(len(groups[1])),
                     "n_pages_2024_2026": int(len(groups[2]))})

kw_df = pd.DataFrame(kw_rows)
kw_df["fdr_q"] = bh_fdr(kw_df["p_value"].values)
kw_df = kw_df.sort_values("p_value")
kw_df.to_csv(OUT_DIR / "kruskal_wallis_terms_by_period.csv", index=False)

print(f"Kruskal-Wallis tests run on {len(kw_df)} terms (top-60 corpus-wide, page-level rates).")
print(f"Significant at FDR q<0.05: {(kw_df.fdr_q < 0.05).sum()} of {len(kw_df)} terms")
print("\nTop 20 terms by ascending p-value:")
print(kw_df.head(20).to_string(index=False))

# ---------------------------------------------------------------------
# 2. LDA topic-probability comparison across periods (page level)
# ---------------------------------------------------------------------
lda_pages = pd.read_csv(OUT_DIR / "lda_page_topic_assignments.csv")
lda_pages = lda_pages[lda_pages.period != "excluded"]
topic_cols = [c for c in lda_pages.columns if c.startswith("topic_") and c.endswith("_prob")]

topic_kw_rows = []
for col in topic_cols:
    t_idx = int(col.split("_")[1])
    groups = [lda_pages[lda_pages.period == p][col].values for p in PERIODS.keys()]
    h, p_val = stats.kruskal(*groups)
    means = {p: float(lda_pages[lda_pages.period == p][col].mean()) for p in PERIODS.keys()}
    topic_kw_rows.append({"topic": t_idx, "H": float(h), "p_value": float(p_val),
                           "mean_2015_2019": means["2015-2019"], "mean_2020_2022": means["2020-2022"],
                           "mean_2024_2026": means["2024-2026"]})
topic_kw_df = pd.DataFrame(topic_kw_rows)
topic_kw_df["fdr_q"] = bh_fdr(topic_kw_df["p_value"].values)
topic_kw_df = topic_kw_df.sort_values("p_value")
topic_kw_df.to_csv(OUT_DIR / "kruskal_wallis_topics_by_period.csv", index=False)

print(f"\nKruskal-Wallis tests run on {len(topic_kw_df)} LDA topics (page-level topic probabilities).")
print(topic_kw_df.to_string(index=False))

summary = {
    "n_terms_tested": int(len(kw_df)),
    "n_terms_significant_fdr05": int((kw_df.fdr_q < 0.05).sum()),
    "n_topics_tested": int(len(topic_kw_df)),
    "n_topics_significant_fdr05": int((topic_kw_df.fdr_q < 0.05).sum()),
}
json.dump(summary, open(OUT_DIR / "period_stats_summary.json", "w"), indent=2)
print("\nSummary:", summary)
